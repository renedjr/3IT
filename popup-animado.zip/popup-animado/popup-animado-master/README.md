# Popup Animado con HTML, CSS y Javascript
### Ejemplo de ejecucion de Popup Animado con HTML, CSS y Javascrip

Prueba animación JS
Se realiza una carga manual de lista de indicadores, con el fin de realizar un funcionamiento de pestañas MODAL mediante estilos CSS, JS y HTTML.
Para ver funcionamiento básico solo debe abrir el archivo index.html.
